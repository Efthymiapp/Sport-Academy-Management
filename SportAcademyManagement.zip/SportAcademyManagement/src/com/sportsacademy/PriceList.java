package com.sportsacademy;

public interface PriceList {
    double calculateTotalPrice();
}
