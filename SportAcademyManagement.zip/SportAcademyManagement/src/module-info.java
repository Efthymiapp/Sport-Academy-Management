/**
 * 
 */
/**
 * @author Eswterikos
 *
 */
module SportAcademyManagement {
	requires java.desktop;
}